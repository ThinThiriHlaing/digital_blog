---
img: /assets/programmer-wallpaper.webp
pubDate: 2023-03-07T04:18:40.604Z
title: Blog2
description: မြိတ်က အွန်လိုင်းသုံးစွဲသူတွေရဲ့ အကြိုက်က ဘာဖြစ်မလဲ? (1)
paragraph: မြိတ်မြို့မှာလုပ်ကိုင်ကြတဲ့ စီးပွားရေး လုပ်ငန်းတွေဟာ Online Marketing
  ရဲ့ အဓိက အရေးကြီးဆုံး အပိုင်းဖြစ်တဲ့ ကြော်ငြာစာအရေးအသားမှာ အားနည်းတာ၊
  အချိန်မပေးနိုင်တာကို တွေ့ရပါတယ်။

layout: ../../layouts/BlogLayout.astro
---

I﻿t's work!
