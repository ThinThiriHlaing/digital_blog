/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*{astro,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
};
